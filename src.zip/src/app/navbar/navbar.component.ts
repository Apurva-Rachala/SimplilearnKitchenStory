import {Component} from "@angular/core";
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
//import { ApurvaService } from "../apurva.service";
import {faSearch} from "@fortawesome/free-solid-svg-icons"
import {faSignOut} from "@fortawesome/free-solid-svg-icons"
import {faCartShopping} from "@fortawesome/free-solid-svg-icons"
import {faBoxOpen} from "@fortawesome/free-solid-svg-icons"
import { ApurvaService } from "../apurva.service";
import { HttpHeaders } from '@angular/common/http';

@Component({

    selector:"app-navbar",
    templateUrl:"./navbar.component.html"
})
export class NavbarCompomnent{
    //projecttitle:string="Apurva's cake gallery"
    //or use universal datatype any when not sure about the datatype
    projecttitle:any="Apurva's cake gallery"
    searchtext:any
    color:any
    isloggedin:any
    faSearch:any = faSearch
    faSignOut:any = faSignOut
    faCartShopping:any = faCartShopping
    faBoxOpen:any=faBoxOpen
    length:any

    constructor(private toastr: ToastrService, private router: Router, private apurva: ApurvaService ){
        this.isloggedin=localStorage["token"]?true:false
        if(this.isloggedin){
            var url = "https://apifromashu.herokuapp.com/api/cakecart"
            var headers = new HttpHeaders()
            headers = headers.append("authtoken",localStorage["token"])
            var body = {}
            var options = {
               headers:headers
            }
            this.apurva.getCartItems(url,body,options).subscribe({
               next:(response:any)=>{
                  console.log("response from cart items api in navbar", response)
                  this.apurva.cartitems = response.data
                  this.length =  response.data?.length
                  //window.location.reload()
               }
               
            })
         }
    }
    isAdmin:any = false
    //loggedinUser:any

   adminUsers:any = ["apurvarachala@gmail.com"]

    ngDoCheck(){
        this.length =  this.apurva.cartitems?.length

        if(localStorage["token"]){
            this.isloggedin=true
            if(this.adminUsers.includes(localStorage["loggedinUser"])){
                this.isAdmin = true
             }
        }
        else{
            this.isloggedin=false
            this.isAdmin = false
        }
    }
    search(){
        //console.log("......", this.color)
        //alert("oh!hi")
        //check port number
       // alert(this.apurva.PORT)
        //alert(this.searchtext)
        if(this.searchtext)
        this.router.navigate(["/search"], {queryParams:{q:this.searchtext}})
    }
    logout(){
        localStorage.clear();
        this.toastr.success('Logged out successfully')
    }
}