import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Component , OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApurvaService } from './apurva.service';

@Component({
    selector:'app-forgot',
    templateUrl: './forgot.component.html'
})
export class ForgotComponent implements OnInit{
    constructor(private apurvaservice: ApurvaService, private router: Router, private http: HttpClient){
    }
    responseError:any
    userdata:any={

    }    
    forgot(){
        let myheaders=new HttpHeaders()

      myheaders=myheaders.append("authtoken",localStorage["token"])      

      var options={

        headers:myheaders

      }

      var body={}
        var url="https://apifromashu.herokuapp.com/api/recoverpassword"
        this.apurvaservice.forgot(url,this.userdata).subscribe({
            next:(response:any)=>{
                console.log("Response from api", response)
                if(response.token){
                    localStorage["token"]= response.token
                    this.router.navigate(["/login"])
                }
                else{
                    //this.responseError = "Invalid email"
                }
            },
            error:(error)=>{
                console.log("Error from api", error)
            }
        })
    }
    ngOnInit(): void {
        
    }
} 