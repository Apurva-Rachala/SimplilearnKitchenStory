import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApurvaService } from './apurva.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html'
  //styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
    cartitems:any=[]
    totalPrice:any=0
    userAddressdata:any={}
    constructor(

        private apurva: ApurvaService, private http: HttpClient, private route: Router
    
      ) {
    
        var url = 'https://apifromashu.herokuapp.com/api/cakecart';
    
        let myheaders = new HttpHeaders();
    
        myheaders = myheaders.append('authtoken', localStorage['token']);
    
        var options = {
    
          headers: myheaders,
    
        };
    
        var body = {};
    
        this.apurva.getCartItems(url, body, options).subscribe({
    
          next: (response: any) => {
    
            console.log('Response from cart items api', response);
    
            this.cartitems = response.data;
            this.cartitems.forEach((each: any) => {
              this.totalPrice = this.totalPrice + each.price * each.quantity;
    
            });
    
          },
    
          error: (error) => {
    
            console.log('Error from cart items api', error);
    
          },
    
        });
    
        this.userAddressdata = this.apurva.userdata;
        console.log(this.cartitems)
        console.log(this.userAddressdata)

    }

    placeOrder(){
      var url = "https://apifromashu.herokuapp.com/api/addcakeorder";
    
      let myheaders = new HttpHeaders();
  
      myheaders = myheaders.append('authtoken', localStorage['token']);
  
      var options = {
  
        headers: myheaders,
  
      };
  
      var body = {

        cakes: this.cartitems,
        price:this.totalPrice,
        name: this.userAddressdata[0].name,
        address:this.userAddressdata[0].address,
        city: this.userAddressdata[0].city,
        pincode:this.userAddressdata[0].pincode,
        phone:this.userAddressdata[0].phone
      }
      this.http.post(url, body, options).subscribe({
        next: (response: any) => {
          console.log("response from payment", response)
        },
        error: (error)=>{
          console.log("error", error)
        }
      })
this.route.navigate(['/ordersuccess'])
    }
  ngOnInit(): void {
  }

}
