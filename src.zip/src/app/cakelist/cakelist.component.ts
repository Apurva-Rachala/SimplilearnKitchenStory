import { Component } from "@angular/core";
import { ApurvaService } from "src/app/apurva.service";
import { HttpClient } from '@angular/common/http';
import { NgxUiLoaderService } from "ngx-ui-loader";

@Component({
    selector:'app-cakelist',
    //providers: [ApurvaService], //DECLARES EVERLY SERVICE GLOBALLY
    templateUrl:'./cakelist.component.html'
})
export class CakelistComponnet{
    constructor(private apurvaangular:ApurvaService, private http : HttpClient, private ngxService: NgxUiLoaderService){
        var url="https://apifromashu.herokuapp.com/api/allcakes"
        this.http.get(url).subscribe({
            next:(response:any)=>{
                console.log("Response from all cakes api", response)
                this.cakes=response.data
            },
            error:(error)=>{
                console.log("Error from all cakes api", error)
            }
        })
        //get function returns an observable
    }
    //using service and calling the function directly using the constructor (this provides function reusability)
    
    ngOnInit(): void {
        this.ngxService.start(); // start foreground spinner 
        setTimeout(() => {
          this.ngxService.stop(); // stop foreground spinner 
        }, 1000);
      }

    ascSort(){
        this.apurvaangular.PORT = 4200
        this.cakes=this.apurvaangular.ascending(this.cakes)
    }
    descSort(){
        this.apurvaangular.PORT = 4200
        this.cakes=this.apurvaangular.descending(this.cakes)
    }
    cakes:any=[
        /*{name:"Cheese cake", price:750, image:"assets/cheesecake.jpg"},
        {name:"Hazelnut Cake", price:1000, image:"assets/hazelnut.jpg"},
        {name:"Redvelvet Cake", price:1200, image:"https://d2zcsajde7b23y.cloudfront.net/m/e914b74a1f87034659fe692a8e16f12621bd5c52.jpg"},
        {name:"Rainbow Cake", price:1100, image:"https://www.thedottedi.in/pub/media/catalog/product/cache/c9e0b0ef589f3508e5ba515cde53c5ff/r/e/regular_rainbow_cake-dottedi.jpg"},
        {name:"Chocolate Cake", price:500, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSO3Zi0X438Nyak6LAPPn8WlAjUJax5IQtCw2FNjD40AsaVSeoC5seecm3AIsj0UenIUrU&usqp=CAU"},
        {name:"Plum Cake", price:200, image:"https://hangoutcakes.com/image/cache/data/tea-time/plum-cake-400x400.jpg"},
        {name:"Icecream Cake", price:900, image:"https://img.buzzfeed.com/buzzfeed-static/static/enhanced/webdr06/2013/8/6/13/enhanced-buzz-wide-12254-1375809507-8.jpg?output-quality=auto&output-format=auto&downsize=360:*"},
        {name:"Vanilla Buttercream Cake", price:990, image:"https://www.fnp.com/images/pr/l/v20200707215602/vanilla-buttercream-cake-half-kg_1.jpg"}*/
    ]
    //constructor(private apurvaangular:ApurvaService){}

    /*ascSort(){
        this.cakes.sort((obj1:any,obj2:any)=>{
            return obj1.price-obj2.price
        })
    }
    descSort(){
        this.cakes.sort((obj1:any,obj2:any)=>{
            return obj2.price-obj1.price
        })
    }*/
}