import { HttpClient } from '@angular/common/http';
import {Injectable} from '@angular/core';
import { CartComponent } from './cart.component';
@Injectable({
    providedIn: 'root'
})
//for sharing and reusability
export class ApurvaService{
    PORT=8080
    userdata:any = []
    loggedinUser:any
    signup(url:any,body:any){
        return this.http.post(url,body)
    }
    login(url:any,body:any){
        return this.http.post(url,body)
    }    
    forgot(url:any,body:any){
        return this.http.post(url,body)
    }    
    getCakedetails(url:any){
        return this.http.get(url)
    }

    addCakeToCart(url:any,body:any,options:any){
        return this.http.post(url,body,options)
      }
    
      getCartItems(url:any,body:any,options:any){
        return this.http.post(url,body,options)
      }
      addUserAddress(user: any) {
        this.userdata.push(user);   
      }
      cartdetails:any={}
      cartitems:any
      cartinfo(cartdetails:any){
        this.cartdetails=cartdetails
        console.log(this.cartdetails)
      }
      order(url:any,body:any,options:any){
          return this.http.post(url.body,options)
      }
      uploadImage(url:any,body:any,options:any){
        return this.http.post(url,body,options)
    
      }
    ascending(data:any){
        data.sort((obj1:any,obj2:any)=>{
            return obj1.price-obj2.price
        })
        return data
    }
    descending(data:any){
        data.sort((obj1:any,obj2:any)=>{
            return obj2.price-obj1.price
        })
        return data
    }
    constructor(private http:HttpClient){}
}