import {Component} from "@angular/core";
import { ToastrService } from 'ngx-toastr';
import {ApurvaService} from "../apurva.service"
import {FormBuilder, FormGroup, Validators} from "@angular/forms"
@Component({
    selector:"app-signup",
    templateUrl:"./signup.component.html"
})
/*export class SignupCompomnent{
    name:any
    email:any
    password:any
    signup(){
        console.log("......", this.name)
        console.log("......", this.email)
        console.log("......", this.password)
        //alert(this.searchtext)
    }
}*/
export class SignupComponent{
    userdata:any={
 
    }
    signupForm:any

    users:any=[]
    //name:any
    //email:any
    //password:any
    constructor(private apurvaservice:ApurvaService, private formbuilder : FormBuilder){
        this.signupForm= this.formbuilder.group({
            apurva:['',[Validators.required, Validators.email]],
            //to show some email value by default
            //apurva:['apurvarachala@gmail.com',[Validators.required, Validators.email]]
            rachala:['',[Validators.required]],
            sai:['',[Validators.required]]
        })
    }
    
    responseError:any
    
    signup(){
        if(this.signupForm.valid){
            alert()
        }
        else{
            return
        }
        console.log("values entered my user are", this.userdata)
        //alert(this.searchtext)
        var temp={...this.userdata}
        this.users.push(temp)
        //this.toastr.success('You have sucessfully logged in!');
        var url ="https://apifromashu.herokuapp.com/api/register"

        this.apurvaservice.signup(url,this.userdata).subscribe({
            next:(response:any)=>{
                console.log("response from signup api", response)
                if(response.message=="User Already Exists"){
                    this.responseError="Invalid Email or Email already taken"
                }
            },
            error:(error)=>{
            console.log("Error from signup api", error)
            }
        })
    }
    deleteuser(index:any){
        alert(index)
    }
    //constructor(private toastr: ToastrService) {}

  
}
