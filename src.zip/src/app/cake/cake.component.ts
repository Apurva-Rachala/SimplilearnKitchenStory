import {Component, Input, OnInit} from "@angular/core";
import { Router } from "@angular/router";
@Component({
    selector:"app-cake",
    templateUrl:"./cake.component.html"
    //styleUrls:["./cake.component.css"]
})
export class CakeComponent{
    //cakedata:any={
     //   name:"hazelnut",
     //   price:"500/-"
    //}
    //@Input() name : any
    //@Input() price :any
    constructor(private router:Router){
        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>", this.cakedata)
    }

    showCakedetails(){
        this.router.navigate(['/detail',this.cakedata.cakeid])
    }
    ngOnInit(){
        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>...................", this.cakedata)
    }
    @Input() cakedata: any
}