import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from "@angular/common/http"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CakeComponent } from './cake/cake.component';
import { CarouselCompomnent } from './carousel/carousel.component';
import { NavbarCompomnent } from './navbar/navbar.component';
import { SignupComponent } from './signup/signup.component';
import { CakelistComponnet } from './cakelist/cakelist.component';
import { ApurvaService } from './apurva.service';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ToastrModule } from 'ngx-toastr';
import { LoginComponent } from './login.component';
import { HomeComponent } from './home.component';
import { PagenotfoundComponent } from './pagenotfound.component';
import { ForgotComponent } from './forgot.component';
import { SearchComponent } from './search.component';
import { CakedetailComponent } from './cakedetail.component';
import { CartComponent } from './cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { AddressComponent } from './address.component';
import { PaymentComponent } from './payment.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NgxUiLoaderModule } from 'ngx-ui-loader';
import { CheckemailComponent } from './checkemail.component';
import { OrdersComponent } from './orders.component';
import { OrdersuccessComponent } from './ordersuccess.component';
import { AddcakeComponent } from './addcake/addcake.component';

@NgModule({
  declarations: [
    AppComponent, NavbarCompomnent, CarouselCompomnent, CakeComponent, SignupComponent, CakelistComponnet, LoginComponent, HomeComponent, PagenotfoundComponent, ForgotComponent, SearchComponent, CakedetailComponent, CartComponent, CheckoutComponent, AddressComponent, PaymentComponent, CheckemailComponent, OrdersComponent, OrdersuccessComponent, AddcakeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot(), // ToastrModule added
    ReactiveFormsModule,
    NgxUiLoaderModule,
    FontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent],
})
//class MainModule {}
export class AppModule { }
