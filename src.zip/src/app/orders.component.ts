import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Component , OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApurvaService } from './apurva.service';

@Component({
    selector:'app-orders',
    templateUrl: './orders.component.html'
})
export class OrdersComponent implements OnInit{
    orderdata:any

  constructor(private service:ApurvaService, private http:HttpClient) {

    var url = "https://apifromashu.herokuapp.com/api/cakeorders"

    let myheader = new HttpHeaders()

    myheader = myheader.append("authtoken",localStorage["token"])

    var options = {

      headers: myheader

    }

    var body = {}

    this.http.post(url,body,options).subscribe({

      next:(response:any)=>{

        console.log("response from order details is ",response)

        this.orderdata = response.cakeorders

        for(let x of this.orderdata){

          console.log("data",x.orderid)

        }

      },

      error:(error)=>{

        console.log("error from order details is",error)

      }

    })
    console.log(localStorage)

   }
    ngOnInit(): void {
        
    }
} 