import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddcakeComponent } from './addcake/addcake.component';
import { AddressComponent } from './address.component';
import { CakedetailComponent } from './cakedetail.component';
import { CartComponent } from './cart.component';
import { CheckemailComponent } from './checkemail.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { ForgotComponent } from './forgot.component';
import { HomeComponent } from './home.component';
import { LoginComponent } from './login.component';
import { OrdersComponent } from './orders.component';
import { OrdersuccessComponent } from './ordersuccess.component';
import { PagenotfoundComponent } from './pagenotfound.component';
import { PaymentComponent } from './payment.component';
import { SearchComponent } from './search.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {path:"",component:HomeComponent},
  {path:"search", component:SearchComponent},
  {path:"login", component:LoginComponent},
  {path:"signup", component:SignupComponent},
  {path:"forgot", component:ForgotComponent},
  {path:"cart", component:CartComponent},
  {path:"forgot", component:ForgotComponent},
  {path:"checkemail", component:CheckemailComponent},
  {path:"orders", component:OrdersComponent},
  {path:"ordersuccess", component:OrdersuccessComponent},
  {path:"addcake", component: AddcakeComponent},
  //parameterized route
  {path:"detail/:cakeid", component: CakedetailComponent},
  {path:"checkout", component: CheckoutComponent,
  children: [
    {path:"address", component: AddressComponent},
    {path:"payment", component:PaymentComponent},
  ]
},
  //you can add more components/ paths for search, forgot, addcake
  //universal route handler
  //"**" shows page not found for invalid address
  // this should always be placed at the last any path after this would not be considered or opened.
  {path:"**", component:PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
