import { Component, OnInit } from '@angular/core';
import { ApurvaService } from './apurva.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html'
  //styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {
  userdetails:any=[]
  //addUserAddress:any
  constructor(private apurva: ApurvaService) { }
    addAddress(){
        //alert("Valid!")

            let currentUser:any ={
        
              name: this.userdetails.name,
        
            address: this.userdetails.address,
        
            city: this.userdetails.city,
        
            pincode: this.userdetails.pincode,
        
            phone: this.userdetails.phone
        
            };
        
            this.apurva.addUserAddress(currentUser)
        
          }
    
  ngOnInit(): void {
  }

}
