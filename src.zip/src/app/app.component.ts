import { Component } from '@angular/core';
import { ApurvaService } from "src/app/apurva.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ApurvaService],
})
export class AppComponent {
  title = 'angularapp1';
  friends=["Apurva","Ananditha","XYZ","blah"]
  trainees:any=[{
    name:"Apurva",
    salary:"6lpa"
  },{
    name:"Apurva",
    salary:"16lpa"
  },{
    name:"Apurva",
    salary:"60lpa"
  }]
}
