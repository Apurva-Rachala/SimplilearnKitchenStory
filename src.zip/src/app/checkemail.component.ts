import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Component , OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApurvaService } from './apurva.service';

@Component({
    selector:'app-checkemail',
    templateUrl: './checkemail.component.html'
})
export class CheckemailComponent implements OnInit{
    constructor(){
    }

    ngOnInit(): void {
        
    }
} 